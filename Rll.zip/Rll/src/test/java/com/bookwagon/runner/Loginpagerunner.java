package com.bookwagon.runner;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="D:\\wipro intern\\conditionalstatement\\OOPS\\bin\\inheritance\\Rll\\src\\test\\java\\com\\bookwagon\\feature\\Loginpage.feature",
			
glue= {"com.bookwagon.stepdefiniton"},
dryRun=false,
		plugin={"pretty",
				"html:target/myreport2.html",
				  "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
				  "timeline:test-output-thread/"}
)
public class Loginpagerunner extends AbstractTestNGCucumberTests{

}
