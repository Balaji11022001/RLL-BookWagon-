package com.bookwagon.utilities;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Itestlistner implements ITestListener {

    @Override
    public void onTestStart(ITestResult result) {
        System.out.println("Test Case Started: " + result.getName());
        log("Test Case Started: " + result.getName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        System.out.println("Test Case Passed: " + result.getName());
        log("Test Case Passed: " + result.getName());
    }

    @Override
    public void onTestFailure(ITestResult result) {
        System.out.println("Test Case Failed: " + result.getName());
        log("Test Case Failed: " + result.getName());
    }

    @Override
    public void onStart(ITestContext context) {
        System.out.println("TestNG started");
        log("TestNG started");
    }

    @Override
    public void onFinish(ITestContext context) {
        System.out.println("TestNG Finished");
        log("TestNG Finished");
    }

    private void log(String message) {
        String fileName = "test_execution.log";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            LocalDateTime currentTime = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String formattedDateTime = currentTime.format(formatter);
            writer.write("[" + formattedDateTime + "] " + message + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
