package com.bookwagon.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchPage {
    private WebDriver driver;
    @FindBy(id = "inputbar")
    private WebElement searchBar;

    @FindBy(xpath = "/html[1]/body[1]/form[1]/div[10]/div[1]/div[2]/div[2]/div[1]/div[3]/div[1]/a[1]")
    private WebElement byTitle;

    @FindBy(xpath = "//a[contains(text(), 'Rs.1000 - Rs.2000')]")
    private WebElement priceRange;

    @FindBy(xpath = "//a[contains(text(), 'Discount')]")
    private WebElement discount;

    @FindBy(xpath = "//a[contains(text(), 'Shipping')]")
    private WebElement shipping;

    public SearchPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void searchBook(String bookName) {
        searchBar.sendKeys(bookName);
    }

    public void clickByTitle() {
        byTitle.click();
    }

    public void selectPriceRange() {
        priceRange.click();
    }

    public void applyDiscountFilter() {
        discount.click();
    }

    public void applyShippingFilter() {
        shipping.click();
    }
}
