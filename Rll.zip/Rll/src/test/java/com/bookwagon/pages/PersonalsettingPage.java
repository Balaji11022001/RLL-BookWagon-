package com.bookwagon.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PersonalsettingPage {
	WebDriver driver;
	
	 @FindBy(xpath="//input[@id='ctl00_phBody_SignIn_txtEmail']")
	 private WebElement Login_Click;
	 
	 @FindBy(xpath="//input[@id='ctl00_phBody_SignIn_txtPassword']")
	 private WebElement Password_Click;
	 
	 @FindBy(xpath="//a[@id='ctl00_phBody_SignIn_btnLogin']")
	 private WebElement Click_login;
	 
	@FindBy(xpath="//*[@id=\"aspnetForm\"]/header/div[1]/div/div[3]/ul/li[1]/a/span[1]/img")
	private WebElement Myaccount_Click;
	 
	 @FindBy(xpath="//a[@href='accountsetting.aspx']")
	 private WebElement personalsetting_click;
	 
	 @FindBy(xpath="//*[@id='ctl00_phBody_AccountSetting_fvCustomer_txtfname']")
	 private WebElement Firstname_click;
	 
	 @FindBy(xpath="//input[@id='ctl00_phBody_AccountSetting_fvCustomer_txtemail']")
	 private WebElement Email_click;
	 
	 
	 @FindBy(xpath="//*['@id=\"ctl00_phBody_AccountSetting_fvCustomer_txtProfileName\']")
	 private WebElement profilename_click;
	 
	 @FindBy(xpath="//*['@id=\"ctl00_phBody_AccountSetting_fvCustomer_txtMobile\']")
	 private WebElement Mobilenumber_click;
	 
	 
	 @FindBy(xpath="//input[@id='ctl00_phBody_AccountSetting_fvCustomer_imgUpdate']")
	 private WebElement Update_Click;
	 
	 @FindBy(xpath="//span[@id=\"recaptcha-anchor\"]")
	 private WebElement Captcha_click;
	 
	 public PersonalsettingPage(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);	
			
		}
	 public void navigateToURL(String url) {
		 driver.get(url);
	 }
	 
	 public void click_Login(String Email,String Password) {
		 Login_Click.sendKeys(Email);
		 Password_Click.sendKeys(Password);
	 }
	 
	 public void click_Myaccount() {
		 personalsetting_click.click();
		 
		
	 }
	 
	 public void click_Loginbutton() {
		 Click_login.click();
	 }
		 
	 public void click_Mypro() {
		 Myaccount_Click.click();
	 }

	 public void click_Firstname() {
		 Firstname_click.clear();
			Firstname_click.click();
			
		}
		
		public void click_Email(String Email) {
			Email_click.clear();
			Email_click.sendKeys(Email);
			
		}
		
		public void click_Profilename(String Name) {
			profilename_click.sendKeys(Name);
			
			
			
		}
			
			public void Click_Mobilenumber(String Mobilenumber) {
				Mobilenumber_click.sendKeys(Mobilenumber);
				
			}
				
				public void Captcha_click1( ) throws InterruptedException {
				Captcha_click.click();
				Thread.sleep(3000);
			}
			
			public void Click_update() {
				Update_Click.click();
				
				
			}
}
