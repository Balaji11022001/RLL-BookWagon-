package com.bookwagon.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MyshoppingCart {
	public MyshoppingCart(WebDriver driver) {  
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	private final WebDriver driver;
	
	@FindBy(xpath="//input[@id='inputbar']") 
	private WebElement productinput;
	
	@FindBy(xpath="(//input[@type='button'])[1]")
	private WebElement search;
	
	@FindBy(xpath="(//input[@type='button'])[2]")
	private WebElement buynowbutton;
	
	@FindBy(xpath="(//span[@class='itemcount'])[1]")
	private WebElement addtocart;
	
	@FindBy(xpath="(//input[@type='button'])[3]")
	private WebElement addquantity;
	
	@FindBy(xpath="(//input[@type='button'])[2]")
	private WebElement reducequantity;
	
	@FindBy(linkText="Remove")
	private WebElement 	clickremovebutton;
	
	@FindBy(linkText="Click here")
	private WebElement continuebutton;
	
	public void navigateToURL(String url) {   
		driver.get(url);
	}           
	            //method name =type_product calling to stepdef
	public void type_product(String product) {   ////ms.type_product we get xpath to product input and it goes to input and give value throug sendkey
			productinput.sendKeys(product);
			
			//xpath             //sendkey value from step def
			search.click();
	}
	public void search_product(String product) {	
		search.click();	
}
	public void Buynow() throws InterruptedException {
		buynowbutton.click();
		Thread.sleep(3000);
	}
	public void clickaddtocart() {
		 addtocart.click();
	

}
	public void clickaddbutton() {
		 addquantity.click();
	

}
	public void clickreducequantitybutton() throws InterruptedException {
		Thread.sleep(3000);
		reducequantity.click();
	

}
	public void clickremovebutton() throws InterruptedException {
		Thread.sleep(3000);
		clickremovebutton.click();
	}
	

	public void clickcontinue() throws InterruptedException {
		Thread.sleep(3000);
		 continuebutton.click();
	

}

}
