package com.bookwagon.stepdefiniton;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.bookwagon.pages.TestBasepage;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Searchstep extends TestBasepage {
    private static final Logger logger = LogManager.getLogger(Searchstep.class);

    static WebDriver driver;

    @Before
    public void setUp() {
        
        driver = new ChromeDriver();
    }

    public static WebDriver getDriver() {
        return driver;
    }

    @Given("user navigates to the book website")
    public void user_navigates_to_the_book_website() {
        logger.info("I am on Book website page");
        driver.get("https://www.bookswagon.com/");
        driver.manage().window().maximize();
    }

    @When("^user enters the \"([^\"]*)\" and \"([^\"]*)\" credentials$")
    public void user_enters_the_credentials(String Email, String Password) {
        logger.info("Sign in Successfully");
        driver.findElement(By.id("ctl00_lblUser")).click();
        driver.findElement(By.id("ctl00_phBody_SignIn_txtEmail")).sendKeys(Email);
        driver.findElement(By.id("ctl00_phBody_SignIn_txtPassword")).sendKeys(Password);
        driver.findElement(By.id("ctl00_phBody_SignIn_btnLogin")).click();
    }

    @Then("user navigates to the home page")
    public void user_navigates_to_the_home_page() {
        logger.info("I am on the home page");
        String actualText = driver.getTitle();
        String expectedText = "Online BookStore India, Buy Books Online, Buy Book Online India - Bookswagon.com";
        Assert.assertEquals(actualText, expectedText);
    }

    @When("user clicks on search bar and enter the book name")
    public void user_clicks_on_search_bar_and_enter_the_book_name() {
        logger.info("I click on search bar");
        driver.findElement(By.xpath("//input[@id='inputbar']")).sendKeys("Harry potter");
    }

    @When("user click on search button")
    public void user_click_on_search_button() {
        logger.info("I click on search button");
        driver.findElement(By.xpath("//input[@id='btnTopSearch']")).click();
    }

    @When("user refine your search based on title on the books")
    public void user_refine_your_search_based_on_title_on_the_books() {
        logger.info("I refine search based on title");
        driver.findElement(By.xpath("/html[1]/body[1]/form[1]/div[10]/div[1]/div[2]/div[2]/div[1]/div[3]/div[1]/a[1]")).click();
    }

   
   
    @Then("user see list of the books")
    public void user_see_list_of_the_books() {
        logger.info("List of the books displayed");
    }
}
