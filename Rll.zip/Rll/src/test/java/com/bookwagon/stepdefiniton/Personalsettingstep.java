package com.bookwagon.stepdefiniton;

import org.testng.AssertJUnit;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import com.bookwagon.pages.PersonalsettingPage;
import com.bookwagon.stepdefiniton.Personalsettingstep;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Personalsettingstep {
private static final Logger logger = LogManager.getLogger(Personalsettingstep.class);
	
	private final WebDriver driver;
	   private final PersonalsettingPage psp;
	   
		public Personalsettingstep() {
			driver=new ChromeDriver();
			psp=new PersonalsettingPage(driver);
		}
			
	
	@Given("User navigates to the URL")
	
	public void user_navigates_to_the_url() {
	 psp.navigateToURL("https://www.bookswagon.com/"); 
	 driver.manage().window().maximize();
		logger.info("User navigates to the URL");

	}

	@When("User performs the login process")
	public void user_performs_the_login_process() {
		logger.info("User performs the login process");
		psp.click_Mypro();
		psp.click_Login("6382521448", "Balaji@11");
		psp.click_Loginbutton();
	}

	@Then("Validate the login is successful")
	public void validate_the_login_is_successful() {
		logger.info("Validate the login is successful");
	}

	@Then("User clicks on Profilename")
	public void user_clicks_on_profilename() {
		logger.info("User clicks on Profilename");
		psp.click_Myaccount();
	}

	@Then("User update the profile name")
	public void user_update_profile_name()  {
		logger.info("User update the profile name");
   psp.click_Profilename("RLL8173513");
	}

	@Given("User clicks on Personal Settings")
	public void user_clicks_on_personal_settings() {
		logger.info("User clicks on Personal Settings");
	}

	@Given("User add E-mail Id")
	public void user_add_e_mail_id() {
		logger.info("User add E-mail Id");
		psp.click_Email("balajibala09907@gmail.com");
	    
	}

	@Then("enters generated OTP then E-mail Successfully updated")
	public void enters_generated_otp_then_e_mail_successfully_updated() {
		logger.info("enters generated OTP then E-mail Successfully updated");
	
	}

	@And("User add Mobile Number")
	public void user_add_mobile_number() throws InterruptedException, IOException {
		WebElement mobileNumberElement=driver.findElement(By.xpath("//input[@id='ctl00_phBody_AccountSetting_fvCustomer_txtMobile']"));
		@SuppressWarnings("unused")
		String placeholderText=mobileNumberElement.getAttribute("Value");
		@SuppressWarnings("unused")
		String wrongMobileNumber = "1234567890";
		logger.info("User add Mobile Number");
		Thread.sleep(3000);
		mobileNumberElement.clear();
		mobileNumberElement.sendKeys("6382521448");
		Thread.sleep(3000);
		captureScreenshot(driver, "PersonalSettings_Fail1.png");
		
		/* psp.Click_Mobilenumber("wrongMobileNumber"); */
		
				
	}

	
	@Then("enters generated OTP then Mobile Number Successfully updated")
	public void enters_generated_otp_then_mobile_number_successfully_updated() {
		logger.info("enters generated OTP then Mobile Number Successfully updated");
	}
	
	
	@Given("User Can Click Captcha for security setting")
	public void user_can_click_captcha_for_security_setting() {
		logger.info("User Can Click Captcha for security setting");
	}
	
	@Given("User clicks on Update Personal Settings")
	public void user_clicks_on_update_personal_settings() {
		logger.info("User clicks on Update Personal Settings");
		psp.Click_update();
		String e1=driver.getTitle();
		String e2 ="Online BookStore India, Buy Books Online, Buy Book Online India - Bookswagon.com";
				Assert.assertEquals(e2,e1);
				
		
	}
	

	@Given("Click on Cancel button")
	public void click_on_cancel_button() {
		logger.info("Click on Cancel button");
	}

	@Then("user can cancel the personal setting submission")
	public void user_can_cancel_the_personal_setting_submission() {
		logger.info("user can cancel the personal setting submission");
		
	}

	private static void captureScreenshot(WebDriver driver, String fileName) {
		try {
	         // Cast WebDriver to TakesScreenshot
	         TakesScreenshot screenshot = (TakesScreenshot) driver;

	         // Capture the screenshot as a file
	         File sourceFile = screenshot.getScreenshotAs(OutputType.FILE);

	         // Specify the destination path
	         File destinationFile = new File("D:\\wipro intern\\conditionalstatement\\OOPS\\bin\\inheritance\\Rll\\Personalsetting" + fileName + ".png");

	         // Copy the file to the destination path
	         FileUtils.copyFile(sourceFile, destinationFile);
	         
	         System.out.println("Screenshot captured: " + destinationFile.getAbsolutePath());
	     } catch (IOException e) {
	         System.err.println("Error while capturing screenshot: " + e.getMessage());
	     }
	}
	
}
