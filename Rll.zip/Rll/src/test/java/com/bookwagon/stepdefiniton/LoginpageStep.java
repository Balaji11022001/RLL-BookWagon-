package com.bookwagon.stepdefiniton;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;


import com.bookwagon.pages.Loginpage;
import com.bookwagon.stepdefiniton.LoginpageStep;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginpageStep {
	private static Logger logger = LogManager.getLogger(LoginpageStep.class);
	   // BaseClass B;
	    // WebDriver driver=BaseClass. getDriver();
	   //  LoginPages lp=new LoginPages(driver);
	     

	 	static WebDriver driver;
	 	
	 	Loginpage lp;	
	 		public LoginpageStep() {
	 			driver=new ChromeDriver();
	 		    lp = new Loginpage(driver);
	 			
	 		}
	 		
	 				
	@Given("click on the URL of bookswagon website")
	public void click_on_the_url_of_bookswagon_website() {
		 lp.NavigateToURL("https://www.bookswagon.com/"); 
		 driver.manage().window().maximize();
		logger.info("click on the URL of bookswagon website");
		

	}

	@Then("user clicks on myaccount option")
	public void user_clicks_on_myaccount_option() throws InterruptedException {
		lp.MyAccount();
		String expectedTitle = "Online BookStore India, Buy Books Online, Buy Book Online India - Bookswagon.com";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
		logger.error("error");
	}


	
	 /* @Then("user clicks on myaccount option") 
	  public void user_clicks_on_myaccount_option1() throws InterruptedException {
		  logger.info("user clicks on myaccount option"); 
		  lp.MyAccount();
		  lp.clickonemailtext(); 
		  Thread.sleep(2000); 
		  String expectedTitle = "Online BookStore India, Buy Books Online, Buy Book Online India - Bookswagon.com" ;
		  String actualTitle = driver.getTitle(); Assert.assertEquals(expectedTitle,actualTitle); // logger.error("Error occured");
	 
	  }*/





	@When("User enters phone no as {string}")
	public void User_enters_phone_no_as(String phone) {
		lp.EntermobileNumber("6309473269");
		logger.info("email entered successfully");
	}

	@When("User enters password as {string}")
	public void User_enters_password_as(String password) {
	logger.info("User enters password as {string}");
	lp.EnterPassword(password);
	}



	@When("the User press on the login button")
	public void the_user_press_on_the_login_button() throws InterruptedException {
	logger.info("the User press on the login button");
	lp.ClickOnLoginButton();
	Thread.sleep(2000);

	}



	@Then("User should see an error message for wrong password")
	public void user_should_see_error_message_for_wrong_password() {
	String expectedErrorMessage = "Please enter correct password.";
	String actualErrorMessage = lp.getWrongPasswordErrorMessage();

	if (expectedErrorMessage.equals(actualErrorMessage)) {
	    // Assertion passed, take a screenshot
	    lp.captureScreenshot("passed_wrong_password");
	} 

	Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	System.out.println("Error message: " + actualErrorMessage);
	}


	@Then("User should see an error message for wrong Email")
	public void user_should_see_error_message_for_wrong_Email() {
	String expectedErrorMessage = "We didn't find an account with this Email";
	String actualErrorMessage = lp.getWrongUsernameErrorMessage();

	if (expectedErrorMessage.equals(actualErrorMessage)) {
	    // Assertion passed, take a screenshot
	    lp.captureScreenshot("assertion_passed_wrong_Email");
	}

	Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	System.out.println("Error message: " + actualErrorMessage);
	}


	@Then("User should see an error message for wrong phone")
	public void user_should_see_error_message_for_wrong_phone() {
	String expectedErrorMessage = "We didn't find an account with this Mobile.";
	String actualErrorMessage = lp.getWrongUsernameErrorMessage();

	if (expectedErrorMessage.equals(actualErrorMessage)) {
	    // Assertion passed, take a screenshot
	    lp.captureScreenshot("passed_wrong_Phone");
	}

	Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	System.out.println("Error message: " + actualErrorMessage);
	}
}
