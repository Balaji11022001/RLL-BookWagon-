package com.bookwagon.stepdefiniton;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.bookwagon.pages.MyshoppingCart;
import com.bookwagon.stepdefiniton.Myshoppingcartstep;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Myshoppingcartstep {
	private static final Logger logger = LogManager.getLogger(Myshoppingcartstep.class);
	private final WebDriver driver;
	               //MyShoppingCart_Page creating as obj folder oppositr step def
	private final MyshoppingCart ms;
	
	
	public Myshoppingcartstep() {
		driver = new ChromeDriver();
		ms = new MyshoppingCart(driver);
		SoftAssert s=new SoftAssert();
	}
	
	@Given("user navigates home page")
	public void user_navigates_to_the_home_page() {
		logger.info("user navigates to the home page");
		
		try {
			ms.navigateToURL("https://www.bookswagon.com/");
			driver.manage().window().maximize();
        } catch (Exception ex) {
            Assert.fail("Unable to open browser");
        }
	}
	

	
	@When("user enters {string}")
	public void user_enters(String product) { 
		logger.info("user enters {string}");
		
		try {
			ms.type_product(product);
        } catch (Exception ex) {
            Assert.fail("Unable to give input");
        }
	}
	

	@And("user clicks the buy now")
	public void user_clicks_the_buy_now() throws InterruptedException {
		logger.info("user clicks the buy now");
		
		try {
			ms.Buynow();
        } catch (Exception ex) {
            Assert.fail("Unable to click buy now button");
        }
	}
	

	@Then("user clicks on add to cart")
	public void user_clicks_on_add_to_cart() {
		logger.info("user clicks on add to cart");
	
		try {
			ms.clickaddtocart();
        } catch (Exception ex) {
            Assert.fail("Unable to click add to cart");
        }
	}
			
	

	@Then("user adds the quantity")
	public void user_adds_the_quantity() {
		logger.info("user adds the quantity");
	
		try {
			ms.clickaddbutton();
        } catch (Exception ex) {
            Assert.fail("Unable to increse");
        }
	}
	    
	
	
	@And("user reduce the quantity")
	public void user_reduce_the_Quantitu() throws InterruptedException {
		logger.info("user reduce the quantity");
	
		try {
			ms.clickreducequantitybutton(); 
        } catch (Exception ex) {
            Assert.fail("Unable to reduce quantity");
        }
	}
	
	

	@When("user remove the product")
	public void user_remove_the_product() throws InterruptedException {
		logger.info("user remove the product");
		
		try {
			ms.clickremovebutton(); 
        } catch (Exception ex) {
            Assert.fail("Unable to remove the product");
        }
	}
	

	@And("user clicks on continue shopping")
	public void user_clicks_on_continue_shopping() throws InterruptedException {
		logger.info("user clicks on continue shopping");
		
		try {
			ms.clickcontinue(); 
        } catch (Exception ex) {
            Assert.fail("Unable to remove the product");
        }
	}
	

	@Then("message should be displayed {string}")
	public void message_should_be_displayed(String string) {
		logger.info("message should be displayed {string}");
	   
	}
	
	
}
