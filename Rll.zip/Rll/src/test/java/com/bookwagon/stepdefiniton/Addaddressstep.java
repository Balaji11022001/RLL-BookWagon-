package com.bookwagon.stepdefiniton;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.bookwagon.pages.Addaddresspage;
import com.bookwagon.stepdefiniton. Addaddressstep;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Addaddressstep {
private static final Logger logger = LogManager.getLogger( Addaddressstep.class);
	
	WebDriver driver;
	 Addaddresspage lp;
	
	@Given("the URL bookswagon website")
	public void the_url_bookswagon_website() {
		logger.info("the URL bookswagon website");
		// Initialize WebDriver
		driver = new ChromeDriver();

		// Initialize LoginPage with the WebDriver
		lp = new Addaddresspage(driver);

		// Navigate to the URL
		lp.navigateToURL("https://www.bookswagon.com/");
		driver.manage().window().maximize();
	}

	@Then("User clicks myaccount")
	public void User_clicks_myaccount() {
		logger.info("User clicks myaccount");
		lp.MyAccount();
		 String expectedTitle = "Online BookStore India, Buy Books Online, Buy Book Online India - Bookswagon.com";
		  String actualTitle = driver.getTitle();
		  Assert.assertEquals(expectedTitle, actualTitle);
		 logger.error("Error occured");
	}
	
	@When("User enter phone no as {string}")
	public void user_enter_phone_no_as(String string) {
		logger.info("User enter phone no as {string}");
		lp.EnterPhone("6382521448");
	}

	@When("User enter password as {string}")
	public void user_enter_password_as(String string) {
		logger.info("User enter password as {string}");
		lp.EnterPassword("Balaji@11");
	}

	@When("the User clicks login button")
	public void the_user_clicks_login_button() {
		logger.info("the User clicks login button");
		lp.ClickOnLoginButton();
	}
	
	@When("User can clicks on My Address")
	public void user_can_clicks_on_my_address() {
		logger.info("User can clicks on My Address");
	    lp.click_MyAddress();
	}

	@Then("User can clicks on Add Address")
	public void user_can_clicks_on_add_address() {
		logger.info("User can clicks on Add Address");
	    lp.click_AddAddress();
	}
	
	@Then("User enters on the FullName")
	public void user_enters_on_the_full_name() throws InterruptedException {
		logger.info("the User clicks on the login button");
	  lp.Enterfullname("Balaji");
	  Thread.sleep(2000);
	}

	@When("User enters on the StreetAddress")
	public void user_enters_on_the_street_address() throws InterruptedException {
		logger.info("User enters on the StreetAddress");
	  lp.EnterStreetAddress("D/No:23/10,54th street,10th sector,k k Nagar");
	  Thread.sleep(2000);
	}

	@Then("User clicks the country dropdown")
	public void user_clicks_the_country_dropdown() throws InterruptedException {
		logger.info("User clicks the country dropdown");
	  lp.EnterCountry();  
	  Thread.sleep(2000);
	  
	}

	@Then("User clicks the state dropdown")
	public void user_clicks_the_state_dropdown() throws InterruptedException {
		logger.info("User clicks the state dropdown");
	  lp.EnterState();
	  Thread.sleep(2000);
	}

	@Then("User clicks the City dropdown")
	public void user_clicks_the_city_dropdown() throws InterruptedException {
		logger.info("User clicks the City dropdown");
	  lp.EnterCity();
	  Thread.sleep(2000);
	}

	@Then("User enters the Pin code")
	public void user_enters_the_pin_code() throws InterruptedException {
		logger.info("User enters the Pin code");
	  lp.EnterPinCode("600086");  
	  Thread.sleep(2000);
	}

	@Then("User enters the Phone")
	public void user_enters_the_phone() throws InterruptedException {
		logger.info("User enters the Phone");
	  lp.EnterPhone1("9876543295"); 
	  Thread.sleep(2000);
	}

	@Then("User clicks Update Option")
	public void user_clicks_update_option() throws InterruptedException {
		logger.info("User clicks Update Option");
	  lp.ClickUpdate();  
	  Thread.sleep(2000);
	}
}
