package com.bookwagon.stepdefiniton;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.bookwagon.pages.Awardwinningpage;
import com.bookwagon.stepdefiniton.Awardwinningstep;

import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Awardwinningstep {

	WebDriver driver;
	
	Awardwinningpage lp;
	Logger logger = LogManager.getLogger(Awardwinningstep.class);

	@Given("the URL of website")
	public void the_url_of_website() throws InterruptedException {
		// Initialize WebDriver

		driver = new ChromeDriver();

		// Initialize LoginPage with the WebDriver
		lp = new Awardwinningpage(driver);

		// Navigate to the URL
		lp.navigateToURL("https://www.bookswagon.com/");
		driver.manage().window().maximize();
	}

	@Then("click on myaccount")
	public void click_on_myaccount() throws InterruptedException {
		lp.MyAccount();
		String expectedTitle = "Online BookStore India, Buy Books Online, Buy Book Online India - Bookswagon.com";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
		logger.error("error");
	}

	@When("the User enter email as {string}")
	public void the_user_enter_email_as(String userEmail) throws InterruptedException {
		lp.EnterEmail("6382521448");
		logger.info("email entered successfully");
	}


	@When("the User enter password as {string}")
	public void the_user_enter_password_as(String userPassword) throws InterruptedException {
		lp.EnterPassword("Balaji@11");
		logger.info("password entered successfully");
	}

	@When("the User clicks on the login button")
	public void the_user_clicks_on_the_login_button() throws InterruptedException {
		lp.ClickOnLoginButton();
		logger.info("login successfully");
	}

	@When("I click on award winner")
	public void i_click_on_award_winner() throws InterruptedException {
		lp.Award_Winner();
		logger.info("click on award winner is successful");
	}

	@Then("Sort your list by Relevance")
	public void sort_your_list_by_relevance() throws InterruptedException {
		lp.SortYourList_By_Relevance();
		logger.info("Relevance sort by is successful");
	}

	@Then("Sort your list by low to high")
	public void sort_your_list_by_low_to_high() throws InterruptedException {
		lp.Sort_Your_List_By_Price_Low_To_High();
		logger.info("Sort your list by low to high is successful");
	}

	@Then("Sort your list by high to low")
	public void sort_your_list_by_high_to_low() throws InterruptedException {
		lp.Sort_Your_List_By_Price_High_To_Low();
		logger.info("Sort your list by high to low is successful");

	}

	@Then("Sort your list by Discount")
	public void sort_your_list_by_discount() throws InterruptedException {
		lp.Sort_Your_List_By_Discount();
		logger.info("Sort your list by Discount is successful");

	}

	@When("I click on first book to buy")
	public void i_click_on_first_book_to_buy() throws InterruptedException {
		lp.Select_The_Product();
		logger.info("I click on first book to buy is successful");

	}

	@Then("I click on buy now")
	public void i_click_on_buy_now() throws InterruptedException {
		lp.By_product();
		driver. navigate(). back();	
		logger.info("I click on buy now is successful");
	}

	
	  @Then("Add to wish list") public void add_to_wish_list() throws
	  InterruptedException, IOException {
	  
	  lp.Add_wishlist(); String actualvalue=
	  driver.findElement(By.xpath("//a[text()='Add to Wishlist']")).getText();
	  String expectedvalue = "Bookswagon"; TakesScreenshot ts = (TakesScreenshot)
	  driver; File screenshot = ts.getScreenshotAs(OutputType.FILE); String
	  screenshotName = "AwardWinner_Failure_" + "_" + System.currentTimeMillis() + ".png";
	  FileUtils.copyFile(screenshot, new File("./AwardWinnerScreenshots/" + screenshotName));
	  Assert.assertEquals(actualvalue, expectedvalue);
	  }
	  
	  
	 
    
	@After("@awardwinnertest")
	public void tearDown() {
		driver.close();
	}
	/*
	 * * @After public void generateTestStatus(ITestResult result) {
	 * 
	 * if (result.getStatus() == ITestResult.FAILURE) { retry(result);
	 * 
	 * } driver.close(); } public boolean retry(ITestResult result) { if (retryCount
	 * < MAX_RETRY_COUNT) { retryCount++; return true; } return false; }
	 */
}
