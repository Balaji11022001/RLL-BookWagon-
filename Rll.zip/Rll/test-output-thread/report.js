$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"5e686270-a008-4d34-80cb-f8c968dacb12","feature":"Bookswagon Personal Settings","scenario":"User can add and update the AddAddress","start":1711529677240,"group":1,"content":"","tags":"","end":1711529719339,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});